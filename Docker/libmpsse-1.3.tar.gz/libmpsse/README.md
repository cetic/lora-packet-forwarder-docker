libmpsse
========

Open source library for SPI/I2C control via FTDI chips
